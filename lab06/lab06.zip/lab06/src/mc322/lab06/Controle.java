package mc322.lab06;

public class Controle {

}
