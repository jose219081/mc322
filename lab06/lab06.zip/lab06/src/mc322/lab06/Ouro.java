package mc322.lab06;

public class Ouro extends Componente {
	public static int prioridade = 4;
	
	Ouro() {
		super("O", 1000);
	}
}
