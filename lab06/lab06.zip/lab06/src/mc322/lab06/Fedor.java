package mc322.lab06;

public class Fedor extends Componente {
    public static int prioridade = 2;

    Fedor() {
        super.Componentes("f", 0);
    }
}
