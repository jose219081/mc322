package mc322.lab06;

public class Brisa extends Componente {
    public static int prioridade = 1;

    Brisa() {
        super.Componentes("b", 0);
    }
}
