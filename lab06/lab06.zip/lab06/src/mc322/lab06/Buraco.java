package mc322.lab06;

public class Buraco extends Componente {
    public static int prioridade = 4;

    Buraco(String sprite, int score) {
        super.Componentes("B", -1000);
    }

    public void gerarBrisa(Caverna caverna, int []pos){

    }
}
