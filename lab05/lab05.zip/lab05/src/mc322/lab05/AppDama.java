package mc322.lab05;

public class AppDama {

}
