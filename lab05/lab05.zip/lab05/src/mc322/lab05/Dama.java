package mc322.lab05;

public class Dama {
    boolean branco;

    Dama(boolean pBranco){
        boolean branco = pBranco;
    }

    boolean isValid(){
        boolean valid = false;

        return valid;
    }

    boolean isCompatible(){
        boolean compatible = false;

        return compatible;
    }
}
