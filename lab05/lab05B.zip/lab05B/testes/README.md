# Testes
* teste01.csv: Movimento do Peão
* teste02.csv: Captura de peça com o peão
* teste03.csv: Movimento Inválido - Captura de aliado
* teste04.csv: Movimento Inválido - Destino já ocupado
* teste05.csv: Movimento Inválido - Mover casa vazia
* teste06.csv: Ganhando uma partida

Nos testes de ***Movimentos Inválidos*** nem todos os movimentos são inválidos.