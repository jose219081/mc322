module lab05B {
}