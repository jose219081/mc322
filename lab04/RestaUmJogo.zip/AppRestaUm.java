package mc322.lab04;

public class AppRestaUm{

    String executaJogo(){

        return ;
    }
}